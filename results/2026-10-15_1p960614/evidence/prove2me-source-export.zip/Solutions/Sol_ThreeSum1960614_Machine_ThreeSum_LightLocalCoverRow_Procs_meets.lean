/-
Copyright (c) 2026 Anthropic, PBC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
SPDX-License-Identifier: Apache-2.0
-/

import Definitions.Def_APSPSource_RemainingDefinitions
import Definitions.Def_APSPSource_ThreeSumApsp_Lang_Regions
import Definitions.Def_APSPSource_ThreeSumApsp_Lang_Syntax
import Definitions.Def_APSPSource_ThreeSumApsp_Util_Index
import Definitions.Def_APSPSource_ThreeSumApsp_Util_List
import Definitions.Def_ThreeSum1960614_Machine_Bundle003
import Definitions.Def_ThreeSum1960614_Machine_Bundle004
import Definitions.Def_ThreeSum1960614_Machine_Bundle005
import Definitions.Def_ThreeSum1960614_Machine_Bundle006
import Definitions.Def_ThreeSum1960614_Machine_Bundle007
import Definitions.Def_ThreeSum1960614_Machine_Bundle008
import Definitions.Def_ThreeSum1960614_Machine_Bundle009
import Definitions.Def_ThreeSum1960614_Machine_Bundle010
import Definitions.Def_ThreeSum1960614_Machine_Bundle011
import Definitions.Def_ThreeSum1960614_Machine_Bundle013
import Definitions.Def_ThreeSum1962Source_Bundle01
import Definitions.Def_ThreeSum1962Source_Bundle02
import Definitions.Def_ThreeSum1962Source_Bundle03
import Definitions.Def_ThreeSum1962Source_Bundle04
import Definitions.Def_ThreeSum1962Source_Bundle05
import Definitions.Def_ThreeSum1962Source_Bundle06
import Lean
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Group.Int.Defs
import Mathlib.Algebra.GroupWithZero.Nat
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.Order.BigOperators.Group.List
import Mathlib.Algebra.Order.BigOperators.Group.Multiset
import Mathlib.Algebra.Order.Group.Abs
import Mathlib.Algebra.Order.Group.Int
import Mathlib.Algebra.Order.Group.Nat
import Mathlib.Algebra.Order.Group.Unbundled.Abs
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Order.Ring.Int
import Mathlib.Data.Finset.Range
import Mathlib.Data.Int.Notation
import Mathlib.Data.List.GetD
import Mathlib.Data.Nat.Count
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Notation
import Mathlib.Data.Nat.SuccPred
import Mathlib.LinearAlgebra.Matrix.Defs
import Mathlib.Logic.Function.Basic
import Mathlib.Order.ConditionallyCompleteLattice.Basic
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Algebra.Order.Field.Basic
import Mathlib.Algebra.Order.Ring.Abs
import Mathlib.Algebra.Order.Ring.Int
import Mathlib.Data.Int.Cast.Lemmas
import Mathlib.Data.Nat.Cast.Order.Ring
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Theorems.Thm_ThreeSum1960614_Machine_ThreeSum_LightPairFlags_meets
import Theorems.Thm_ThreeSum1960614_Machine_ThreeSum_LightSupportMark_meets

namespace Light
end Light
namespace ThreeSum
end ThreeSum
namespace ThreeSum.LightLocalCoverRow
end ThreeSum.LightLocalCoverRow
namespace ThreeSum1960614.Machine.Light
end ThreeSum1960614.Machine.Light
namespace ThreeSum1960614.Machine.ThreeSum
end ThreeSum1960614.Machine.ThreeSum
namespace ThreeSum1960614.Machine.ThreeSum.LightLocalCoverRow
end ThreeSum1960614.Machine.ThreeSum.LightLocalCoverRow

namespace ThreeSum1960614.Machine

/-!
# Calls

Meets lim P p d vals μ T R is the specification of a procedure: procedure number p of the program P,
run at depth d on the arguments vals in the memory μ, ends within T steps with a result and a memory
that satisfy R. A routine is proved to meet such a specification (Meets.of_body), and a caller uses
the specification only, so that the proof of a caller does not depend on the body of a callee.

The specification of a routine x, as its callers assume it, has the form
`∀ (data) μ, hypotheses → ∀ d, d + k ≤ lim.depth → Meets lim P p d vals μ T R`.  Here k is the
number of levels of calls that x needs below itself, and d, the depth at which the body of x runs,
comes last.

There is one rule for calls, in four forms.  It is told the fact about the callee, from which it
reads the values of the arguments, the time and what holds afterwards, and it asks for what follows
the call.  Three side goals have default proofs: the arguments are safe and have these values, one
more level of calls is allowed, and the time suffices.  Ends.callTo and Ends.callToThen are the rule
for a state ⟨frame l, μ⟩; Ends.callLast and Ends.callThen are the same for local variables that are
not given as a list.
-/

@[expose] public section

namespace Light
open _root_.Light


variable {lim : _root_.ThreeSum1960614.Machine.Light.Limits} {P : _root_.ThreeSum1960614.Machine.Light.Program} {d : ℕ}

/-! ## Specifications of procedures -/



section
variable {p : ℕ} {vals : List ℤ} {μ : ℕ → ℤ} {T T' : ℕ} {R R' : ℤ → (ℕ → ℤ) → Prop}

/-- From a theorem about a body to the specification. -/
theorem Meets.of_body {args : List ℤ} {Q : ℤ → (ℕ → ℤ) → Prop} {body : _root_.ThreeSum1960614.Machine.Light.Stmt}
    (hp : P[p]? = some body)
    (h : _root_.ThreeSum1960614.Machine.Light.Ends lim P d body ⟨_root_.Light.frame args, μ⟩ T fun σ' => Q (σ'.loc 0) σ'.mem) :
    _root_.ThreeSum1960614.Machine.Light.Meets lim P p d args μ T Q :=
  ⟨body, hp, h⟩









end

/-! ## The rule for calls -/

section
variable {loc μ : ℕ → ℤ} {l : List ℤ} {T T' p x : ℕ} {args : List _root_.ThreeSum1960614.Machine.Light.Expr} {vals : List ℤ}
  {R : ℤ → (ℕ → ℤ) → Prop} {Q : _root_.ThreeSum1960614.Machine.Light.State → Prop} {s : _root_.ThreeSum1960614.Machine.Light.Stmt}









end

end Light

end

end ThreeSum1960614.Machine

section
open _root_.ThreeSum
open _root_.ThreeSum1960614.Machine.ThreeSum

open _root_.ThreeSum.LightLocalCoverRow
open _root_.ThreeSum1960614.Machine.ThreeSum.LightLocalCoverRow

open _root_.Light
open _root_.ThreeSum1960614.Machine.Light
variable {lim : _root_.ThreeSum1960614.Machine.Light.Limits} {P : _root_.ThreeSum1960614.Machine.Light.Program} {d : ℕ}
section


theorem ThreeSum1960614.Machine.ThreeSum.LightLocalCoverRow.Procs.meets__implementation_9c4d814925 {pMain : ℕ} (S : _root_.ThreeSum1960614.Machine.ThreeSum.LightLocalCoverRow.Procs P pMain)
    {μ : ℕ → ℤ} {bitPtr leftPtr rightPtr leftHist rightHist dst n L p cap keys : ℕ}
    (bits : ℕ → ℕ → ℕ) (left right leftCount rightCount : ℕ → ℕ)
    (hw : (lim.space : ℤ) ≤ lim.word) (hd : d+1 < lim.depth) (hn : 0 < n) (hp : 0 < p)
    (hbits : bitPtr+n*L ≤ keys) (hleft : leftPtr+n ≤ keys) (hright : rightPtr+n ≤ keys)
    (hleftHist : leftHist+p ≤ keys) (hrightHist : rightHist+p ≤ keys)
    (hdst : dst+p*p ≤ keys) (hspace : keys+2*(n*n) ≤ lim.space)
    (hword : (_root_.ThreeSum.LightPairFlags.word L n p cap : ℤ) ≤ lim.word)
    (hbitsRead : ∀ i < n, ∀ j < L, μ (bitPtr+i*L+j) = (bits i j : ℤ))
    (hbitsValue : ∀ i < n, ∀ j < L, bits i j ≤ 1)
    (hleftRead : ∀ i < n, μ (leftPtr+i) = (left i : ℤ))
    (hrightRead : ∀ i < n, μ (rightPtr+i) = (right i : ℤ))
    (hleftLt : ∀ i < n, left i < p) (hrightLt : ∀ i < n, right i < p)
    (hleftCount : ∀ r < p, μ (leftHist+r) = (leftCount r : ℤ))
    (hrightCount : ∀ r < p, μ (rightHist+r) = (rightCount r : ℤ))
    (hleftBound : ∀ r < p, leftCount r ≤ n) (hrightBound : ∀ r < p, rightCount r ≤ n) :
    _root_.ThreeSum1960614.Machine.Light.Meets lim P pMain d [bitPtr,leftPtr,rightPtr,leftHist,rightHist,dst,n,L,p,cap,keys] μ (_root_.ThreeSum.LightLocalCoverRow.time L n p)
      (fun _ μ' =>
        (∀ r < p*p, μ' (dst+r) =
          (_root_.ThreeSum.LightSupportMark.bit (_root_.ThreeSum.LightPairFlags.pairKey n p left right)
            (_root_.ThreeSum.LightPairFlags.pairFlag L n cap bits left right leftCount rightCount) r (n*n) : ℤ)) ∧
        _root_.ThreeSum1960614.Machine.Light.KeptBut μ μ' keys dst (p*p)) := by
  have hbudget (x : ℕ) (hx : x ≤ _root_.ThreeSum.LightPairFlags.word L n p cap) : (x : ℤ) ≤ lim.word :=
    (Int.ofNat_le.mpr hx).trans hword
  have hnWord := hbudget n (by unfold _root_.ThreeSum.LightPairFlags.word; omega)
  have hpWord := hbudget p (by unfold _root_.ThreeSum.LightPairFlags.word; omega)
  have hLWord := hbudget L (by unfold _root_.ThreeSum.LightPairFlags.word; omega)
  have hcapWord := hbudget cap (by unfold _root_.ThreeSum.LightPairFlags.word; omega)
  have heWord := hbudget (n*n) (by unfold _root_.ThreeSum.LightPairFlags.word; omega)
  have htWord := hbudget (p*p) (by unfold _root_.ThreeSum.LightPairFlags.word; omega)
  have h1Word := hbudget 1 (by unfold _root_.ThreeSum.LightPairFlags.word; omega)
  have heWordZ : (n : ℤ)*n ≤ lim.word := by exact_mod_cast heWord
  have htWordZ : (p : ℤ)*p ≤ lim.word := by exact_mod_cast htWord
  apply _root_.ThreeSum1960614.Machine.Light.Meets.of_body S.main
  unfold _root_.ThreeSum1960614.Machine.ThreeSum.LightLocalCoverRow.body _root_.ThreeSum.LightLocalCoverRow.time
  have hpair := _root_.ThreeSum1960614.Machine.ThreeSum.LightPairFlags.meets (d := d+1) (μ := μ) (bitPtr := bitPtr)
    (leftPtr := leftPtr) (rightPtr := rightPtr) (leftHist := leftHist) (rightHist := rightHist)
    (dst := keys) (n := n) (L := L) (p := p) (cap := cap)
    S.pair S.divide S.dot S.trim bits left right leftCount rightCount
    hw (by omega) hn hp hbits hleft hright hleftHist hrightHist hspace hword
    hbitsRead hbitsValue hleftRead hrightRead hleftLt hrightLt hleftCount hrightCount hleftBound hrightBound
  (focus
     ((first
         | refine _root_.ThreeSum1960614.Machine.Light.Ends.seqSelf ?_
         | refine _root_.ThreeSum1960614.Machine.Light.Ends.skipLast ?_);
       repeat
         with_unfolding_none
           first
           | refine _root_.ThreeSum1960614.Machine.Light.Ends.seqAssoc ?_
           | refine _root_.ThreeSum1960614.Machine.Light.Ends.skipThen ?_)
     first
     | refine _root_.ThreeSum1960614.Machine.Light.Ends.callToThen (hpair _ (by omega)) ?_ ?_ ?_ ?_
     | refine _root_.ThreeSum1960614.Machine.Light.Ends.callToThen hpair ?_ ?_ ?_ ?_
     on_goal -1 =>
       first
       | ( simp only [_root_.ThreeSum1960614.Machine.Light.Stmt.blockCost, _root_.ThreeSum1960614.Machine.Light.Cond.cost, _root_.ThreeSum1960614.Machine.Light.Expr.cost, _root_.List.map_cons, _root_.List.map_nil, _root_.List.sum_cons, _root_.List.sum_nil, _root_.ThreeSum.LightPairFlags.time, _root_.ThreeSum.LightPairFlags.roundTime, _root_.ThreeSum.LightBooleanDot.time, _root_.ThreeSum.LightTrimTest.time, _root_.ThreeSum.LightSupportMark.time, _root_.ThreeSum.LightSupportMark.markTime]
           first
           | omega
           | (ring_nf; omega))
       | omega
       |
         (simp [_root_.ThreeSum.LightPairFlags.time, _root_.ThreeSum.LightPairFlags.roundTime, _root_.ThreeSum.LightBooleanDot.time, _root_.ThreeSum.LightTrimTest.time, _root_.ThreeSum.LightSupportMark.time, _root_.ThreeSum.LightSupportMark.markTime] <;>
             first
             | omega
             | (ring_nf; omega))
     on_goal -1 => omega
     on_goal -1 =>
       ( (try have := _root_.ThreeSum1960614.Machine.Light.Std.space_le (by assumption))
         (try have := _root_.ThreeSum1960614.Machine.Light.Std.const_le (by assumption))
         simp [_root_.ThreeSum1960614.Machine.Light.Limits.Addr, _root_.abs_le, -_root_.abs_mul, _root_.ThreeSum.LightPairFlags.time, _root_.ThreeSum.LightPairFlags.roundTime, _root_.ThreeSum.LightBooleanDot.time, _root_.ThreeSum.LightTrimTest.time, _root_.ThreeSum.LightSupportMark.time, _root_.ThreeSum.LightSupportMark.markTime] <;> omega)
     on_goal -1 => (rintro value₀ μ₁ ⟨hkeys, hflags, hkept₀⟩; try with_unfolding_none refine _root_.ThreeSum1960614.Machine.Light.Ends.skip ?_))
  have hkeyLt : ∀ i < n*n, _root_.ThreeSum.LightPairFlags.pairKey n p left right i < p*p := by
    intro i hi
    have hq : i/n < n := (Nat.div_lt_iff_lt_mul hn).mpr hi
    have hr := Nat.mod_lt i hn
    have hl := hleftLt _ hq
    have hh := hrightLt _ hr
    unfold _root_.ThreeSum.LightPairFlags.pairKey
    nlinarith
  have hs := _root_.ThreeSum1960614.Machine.ThreeSum.LightSupportMark.meets (d := d+1) (μ := μ₁)
    (keys := keys) (flags := keys+n*n) (dst := dst) (n := n*n) (p := p*p)
    S.support S.fill (_root_.ThreeSum.LightPairFlags.pairKey n p left right)
    (_root_.ThreeSum.LightPairFlags.pairFlag L n cap bits left right leftCount rightCount)
    hw (by omega) (by omega) (by omega) (by omega) (Or.inr hdst) (Or.inr (by omega))
    hkeys hflags hkeyLt h1Word
  (focus
     ((first
         | refine _root_.ThreeSum1960614.Machine.Light.Ends.seqSelf ?_
         | refine _root_.ThreeSum1960614.Machine.Light.Ends.skipLast ?_);
       repeat
         with_unfolding_none
           first
           | refine _root_.ThreeSum1960614.Machine.Light.Ends.seqAssoc ?_
           | refine _root_.ThreeSum1960614.Machine.Light.Ends.skipThen ?_)
     first
     | refine _root_.ThreeSum1960614.Machine.Light.Ends.callToThen (hs _ (by omega)) ?_ ?_ ?_ ?_
     | refine _root_.ThreeSum1960614.Machine.Light.Ends.callToThen hs ?_ ?_ ?_ ?_
     on_goal -1 =>
       first
       | ( simp only [_root_.ThreeSum1960614.Machine.Light.Stmt.blockCost, _root_.ThreeSum1960614.Machine.Light.Cond.cost, _root_.ThreeSum1960614.Machine.Light.Expr.cost, _root_.List.map_cons, _root_.List.map_nil, _root_.List.sum_cons, _root_.List.sum_nil, _root_.ThreeSum.LightPairFlags.time, _root_.ThreeSum.LightPairFlags.roundTime, _root_.ThreeSum.LightBooleanDot.time, _root_.ThreeSum.LightTrimTest.time, _root_.ThreeSum.LightSupportMark.time, _root_.ThreeSum.LightSupportMark.markTime]
           first
           | omega
           | (ring_nf; omega))
       | omega
       |
         (simp [_root_.ThreeSum.LightPairFlags.time, _root_.ThreeSum.LightPairFlags.roundTime, _root_.ThreeSum.LightBooleanDot.time, _root_.ThreeSum.LightTrimTest.time, _root_.ThreeSum.LightSupportMark.time, _root_.ThreeSum.LightSupportMark.markTime] <;>
             first
             | omega
             | (ring_nf; omega))
     on_goal -1 => omega
     on_goal -1 =>
       ( (try have := _root_.ThreeSum1960614.Machine.Light.Std.space_le (by assumption))
         (try have := _root_.ThreeSum1960614.Machine.Light.Std.const_le (by assumption))
         simp [_root_.ThreeSum1960614.Machine.Light.Limits.Addr, _root_.abs_le, -_root_.abs_mul, _root_.ThreeSum.LightPairFlags.time, _root_.ThreeSum.LightPairFlags.roundTime, _root_.ThreeSum.LightBooleanDot.time, _root_.ThreeSum.LightTrimTest.time, _root_.ThreeSum.LightSupportMark.time, _root_.ThreeSum.LightSupportMark.markTime] <;> omega)
     on_goal -1 => (rintro value₁ μ₂ ⟨hrow, hkept₁⟩; try with_unfolding_none refine _root_.ThreeSum1960614.Machine.Light.Ends.skip ?_))
  refine ⟨hrow,?_⟩
  intro a ⟨ha,hout⟩
  change μ₂ a = μ a
  rw [hkept₁ a hout]
  exact hkept₀ a (Or.inl ha)
end

end

theorem solution : type_of% (@ThreeSum1960614.Machine.ThreeSum.LightLocalCoverRow.Procs.meets__implementation_9c4d814925) := (@ThreeSum1960614.Machine.ThreeSum.LightLocalCoverRow.Procs.meets__implementation_9c4d814925)

#print axioms solution
