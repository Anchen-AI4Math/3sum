from pathlib import Path
import subprocess
import sys
root = Path(__file__).resolve().parent
for script in [root / "3sum_exponent_research_2026-10-13/3sum-research/verify_exponents.py", root / "independent_audit.py"]:
    subprocess.run([sys.executable, str(script)], cwd=root, check=True)
print("Reproduction complete. No Lean build performed.")
