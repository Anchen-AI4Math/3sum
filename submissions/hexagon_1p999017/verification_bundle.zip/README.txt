Run: python reproduce.py
This archive is supplementary local reproducibility material, not the Hexagon source upload.
The original verifier is unchanged. The independent checker includes archive integrity checks.
No complete Lean certification is included.
